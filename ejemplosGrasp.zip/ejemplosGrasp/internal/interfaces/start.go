package interfaces

type Start interface {
	StartVehicle() string
}
